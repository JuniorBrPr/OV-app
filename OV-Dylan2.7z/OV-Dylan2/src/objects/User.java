package objects;

public class User {
}
