import java.awt.*;
import java.awt.event.ActionEvent;
public class OvApp
{


        public static void main(String[] args)
        {
            HomeGui g = new HomeGui();
            g.setBounds(400,200,600,400);
            g.setVisible(true);
            g.setBackground(Color.BLACK);
           

        }
}


